class Arvore:

    def __init__(self):
        self.__raiz = None

    def setRaiz(self,raiz:Componente):
        self.__raiz = raiz

    