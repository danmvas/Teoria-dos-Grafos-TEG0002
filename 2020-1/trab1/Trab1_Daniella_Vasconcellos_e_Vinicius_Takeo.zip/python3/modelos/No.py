class No(Componente):

    def __init__(self):
        super(Componente, self).__init__(None)
