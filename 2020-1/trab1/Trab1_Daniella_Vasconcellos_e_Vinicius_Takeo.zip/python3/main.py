from algoritmos.Algoritmo import Algoritmo
from graphviz import Digraph

a = Algoritmo(30)
a.gerarPontos()
a.construirGrafo()
a.geraImagens(0)
a.geraGif()