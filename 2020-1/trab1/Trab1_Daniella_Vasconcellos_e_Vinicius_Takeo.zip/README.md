# Trabalho 1 de TEG

## Necessário instalar

### Graphviz

https://graphviz.org/download/

#### Windows

Basta instalar via choco:

    choco install graphviz

Ou pelo diretamente no powershell:

    winget install graphviz

### Pacotes do python

https://pypi.org/project/imageio/
    Basta executar o comando:
        pip3 install imageio

https://pypi.org/project/graphviz/
    Basta executar o comando:
        pip3 install graphviz



